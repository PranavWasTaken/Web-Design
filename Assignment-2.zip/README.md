
## The <p> and </p> are the HTML tags and “Paragraph Tag” is the HTML element, i.e. the on-page text. This tag formats any text between the opening <p> tag and the closing </p> tag as a standard paragraph or main body text. 

## <h2> and </h2> are the HTML tags and “Heading Tag” is the HTML element, i.e. the on-page heading. Using this tag will format any text between the opening <h2> tag and the closing </h2> tag as a Heading 2 (a type of subheading.) 

## <button>	Defines a clickable button

## The <div> tag defines a division or a section in an HTML document.

## <i>	Defines a part of text in an alternate voice or mood

## <a>	Defines a hyperlink

## <body>	Defines the document's body


