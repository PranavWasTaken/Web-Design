
#### The  “Paragraph Tag” is the HTML element, i.e. the on-page text. This tag formats any text between the opening tag and the closing  tag as a standard paragraph or main body text. 

#### The “Heading Tag is the HTML element, i.e. the on-page heading. Using this tag will format any text between the opening tag and the closing tag as a Heading 2 (a type of subheading.) 

#### The Button Tag 	Defines a clickable button

#### The Div tag defines a division or a section in an HTML document.

#### The I tag 	Defines a part of text in an alternate voice or mood

#### The aDefines a hyperlink

#### The body tag	Defines the document's body

Link : websavant.netlify.app


